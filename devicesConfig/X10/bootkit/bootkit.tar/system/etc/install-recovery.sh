#!/system/xbin/sh

run-parts /system/etc/init.d >> /data/local/tmp/runparts.log 2>&1